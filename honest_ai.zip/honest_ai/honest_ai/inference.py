"""Inference helpers for the fine-tuned ("Honest AI") model and for a
generic HF chat model used as the RAG generator in the hybrid approach.
"""
from typing import Optional

from .config import QLoRAConfig
from .prompts import build_finetuned_prompt


class HFTextGenerator:
    """Thin wrapper around a HF causal LM (optionally with a LoRA adapter)
    for greedy/short-answer generation. Kept minimal and dependency-light;
    swap in vLLM/TGI for real throughput.
    """

    def __init__(self, model_name_or_path: str, adapter_path: Optional[str] = None, **hf_kwargs):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.tokenizer = AutoTokenizer.from_pretrained(model_name_or_path)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        self.model = AutoModelForCausalLM.from_pretrained(
            model_name_or_path, device_map="auto", **hf_kwargs
        )

        if adapter_path:
            from peft import PeftModel

            self.model = PeftModel.from_pretrained(self.model, adapter_path)

        self.model.eval()
        self._torch = torch

    def generate(self, prompt: str, max_new_tokens: int = 64, temperature: float = 0.0) -> str:
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        with self._torch.no_grad():
            output_ids = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=temperature > 0.0,
                temperature=max(temperature, 1e-5),
                pad_token_id=self.tokenizer.pad_token_id,
            )
        full_text = self.tokenizer.decode(output_ids[0], skip_special_tokens=True)
        # Return only the newly generated continuation.
        return full_text[len(self.tokenizer.decode(inputs["input_ids"][0], skip_special_tokens=True)) :].strip()


class FineTunedHonestModel:
    """Convenience wrapper: prompt formatting + generation for the
    QLoRA-fine-tuned "say I don't know" model.
    """

    def __init__(self, base_model: str, adapter_path: str, **hf_kwargs):
        self._gen = HFTextGenerator(base_model, adapter_path=adapter_path, **hf_kwargs)

    def answer(self, query: str, max_new_tokens: int = 64) -> str:
        prompt = build_finetuned_prompt(query)
        return self._gen.generate(prompt, max_new_tokens=max_new_tokens)
