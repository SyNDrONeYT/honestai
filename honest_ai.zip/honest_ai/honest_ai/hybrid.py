"""
Hybrid approach, reproducing Section 3.5 / Figure 4 of the paper.

    "The hybrid approach first utilized the vanilla Meta-Llama-3-8B-Instruct
    to serve as the RAG model to generate results that include domain and
    answer information. The next step is to determine if the domain belongs
    to the movie domain ... If it is in the movie domain and the answer is
    valid, the answer is used as the final answer. If the answer is
    invalid, the question is sent to the Fine-tuned Question Type Model...
    Specifically, an answer is considered 'invalid' in two scenarios: when
    the response is 'invalid question,' or when there is a JSON processing
    error."
"""
from dataclasses import dataclass
from typing import Callable, List, Optional, Protocol

from .config import HybridConfig, RAGConfig
from .prompts import build_domain_and_answer_prompt
from .pruner import SentenceBertPruner
from .utils import extract_first_json, normalize_answer


class TextGenerator(Protocol):
    """Anything with a `.generate(prompt: str) -> str` method: your RAG LLM
    (e.g. HFTextGenerator from inference.py) or a wrapped API model.
    """

    def generate(self, prompt: str, **kwargs) -> str:  # pragma: no cover - protocol
        ...


class FineTunedAnswerer(Protocol):
    def answer(self, query: str, **kwargs) -> str:  # pragma: no cover - protocol
        ...


@dataclass
class HybridResult:
    final_answer: str
    domain: Optional[str]
    rag_raw_output: str
    rag_answer: Optional[str]
    used_source: str  # "rag" or "fine_tuned"
    invalid_reason: Optional[str]
    meets_similarity_threshold: bool


class HybridAnswerer:
    """Orchestrates: retrieve -> prune -> RAG-generate (domain+answer JSON)
    -> route to RAG answer (movie domain, valid) or fine-tuned model
    (everything else / invalid RAG answer).
    """

    def __init__(
        self,
        rag_generator: TextGenerator,
        fine_tuned_model: FineTunedAnswerer,
        pruner: Optional[SentenceBertPruner] = None,
        hybrid_cfg: HybridConfig = HybridConfig(),
        rag_cfg: RAGConfig = RAGConfig(),
    ):
        self.rag_generator = rag_generator
        self.fine_tuned_model = fine_tuned_model
        self.pruner = pruner or SentenceBertPruner(rag_cfg)
        self.hybrid_cfg = hybrid_cfg
        self.rag_cfg = rag_cfg

    def _is_invalid_rag_answer(self, parsed_json: Optional[dict], raw_output: str) -> Optional[str]:
        """Returns a reason string if invalid, else None."""
        if parsed_json is None:
            return "json_processing_error"
        answer = str(parsed_json.get("answer", "")).strip().lower()
        if answer == self.hybrid_cfg.invalid_question_text:
            return "invalid_question"
        return None

    def answer(self, query: str, retrieved_documents: List[str]) -> HybridResult:
        context = self.pruner.build_context(query, retrieved_documents)

        prompt = build_domain_and_answer_prompt(query, context.references_text)
        raw_output = self.rag_generator.generate(prompt)
        parsed = extract_first_json(raw_output)

        domain = parsed.get("domain") if parsed else None
        rag_answer = parsed.get("answer") if parsed else None
        invalid_reason = self._is_invalid_rag_answer(parsed, raw_output)

        is_rag_first_domain = (
            domain is not None
            and normalize_answer(domain) in [normalize_answer(d) for d in self.hybrid_cfg.rag_first_domains]
        )

        if is_rag_first_domain and invalid_reason is None and context.meets_threshold:
            return HybridResult(
                final_answer=rag_answer,
                domain=domain,
                rag_raw_output=raw_output,
                rag_answer=rag_answer,
                used_source="rag",
                invalid_reason=None,
                meets_similarity_threshold=context.meets_threshold,
            )

        # Fall back to the fine-tuned "Honest AI" model: it's good at false
        # premise questions and modestly says "i don't know" otherwise.
        fine_tuned_answer = self.fine_tuned_model.answer(query)
        reason = invalid_reason or (
            "below_similarity_threshold" if not context.meets_threshold else "not_rag_first_domain"
        )
        return HybridResult(
            final_answer=fine_tuned_answer,
            domain=domain,
            rag_raw_output=raw_output,
            rag_answer=rag_answer,
            used_source="fine_tuned",
            invalid_reason=reason,
            meets_similarity_threshold=context.meets_threshold,
        )
