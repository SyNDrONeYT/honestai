"""
Sentence pruner, reproducing Section 3.5 of the paper.

    "This pruner computes the cosine similarity of each sentence W_ij in the
    document with the question Q_i, after converting them to Sentence-BERT
    embeddings. For each top sentence, the following m sentences in the
    paragraph are appended to the context to enrich the information. To
    ensure content quality, an additional cosine similarity threshold n is
    applied, and the answer is used only if this threshold is met for top k
    sentences."

cosine_similarity(Q_i, W_ij) = (Q_i . W_ij) / (||Q_i|| ||W_ij||)     -- Eq. 1
"""
import re
from dataclasses import dataclass
from typing import List, Sequence

import numpy as np

from .config import RAGConfig


def split_into_sentences(text: str) -> List[str]:
    """Lightweight sentence splitter (no heavy NLP dependency required).

    Splits on ./!/? followed by whitespace, while trying not to break on
    common abbreviations. For production use, swap in nltk.sent_tokenize or
    spacy's sentencizer.
    """
    text = text.strip()
    if not text:
        return []
    # Protect a few common abbreviations from being treated as sentence ends.
    protected = re.sub(r"\b(Mr|Mrs|Ms|Dr|St|vs|e\.g|i\.e)\.", r"\1<DOT>", text)
    parts = re.split(r"(?<=[.!?])\s+", protected)
    return [p.replace("<DOT>", ".").strip() for p in parts if p.strip()]


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Row-wise cosine similarity between a single vector `a` (shape [d]) and
    a matrix of vectors `b` (shape [n, d]) -- implements Equation 1.
    """
    a_norm = a / (np.linalg.norm(a) + 1e-12)
    b_norm = b / (np.linalg.norm(b, axis=1, keepdims=True) + 1e-12)
    return b_norm @ a_norm


@dataclass
class PrunedDocument:
    text: str
    top_sentence_scores: List[float]
    meets_threshold: bool


class SentenceBertPruner:
    """Wraps a Sentence-BERT model to prune retrieved documents down to the
    top-k query-relevant sentences (plus each one's following m sentences
    of context), gated by a similarity threshold n.
    """

    def __init__(self, cfg: RAGConfig = RAGConfig(), model=None):
        self.cfg = cfg
        if model is not None:
            self._model = model
        else:
            # Lazy import: sentence-transformers is an optional, somewhat
            # heavy dependency and shouldn't be required just to import this
            # module (e.g. for unit-testing the pure-python logic below).
            from sentence_transformers import SentenceTransformer

            self._model = SentenceTransformer(cfg.sentence_bert_model)

    def _embed(self, sentences: Sequence[str]) -> np.ndarray:
        return np.asarray(self._model.encode(list(sentences), convert_to_numpy=True))

    def prune(self, query: str, document_text: str) -> PrunedDocument:
        sentences = split_into_sentences(document_text)
        if not sentences:
            return PrunedDocument(text="", top_sentence_scores=[], meets_threshold=False)

        query_emb = self._embed([query])[0]
        sent_embs = self._embed(sentences)
        scores = cosine_similarity(query_emb, sent_embs)

        k = min(self.cfg.top_k_sentences, len(sentences))
        top_idx = np.argsort(-scores)[:k]
        top_idx_sorted = sorted(top_idx.tolist())  # keep original document order
        top_scores = [float(scores[i]) for i in top_idx_sorted]

        meets_threshold = all(s >= self.cfg.similarity_threshold_n for s in top_scores)

        # For each top sentence, append the following m sentences (context
        # window), de-duplicating overlapping ranges, in original order.
        selected_indices = set()
        for idx in top_idx_sorted:
            for j in range(idx, min(idx + 1 + self.cfg.context_window_m, len(sentences))):
                selected_indices.add(j)

        pruned_text = " ".join(sentences[i] for i in sorted(selected_indices))
        return PrunedDocument(
            text=pruned_text, top_sentence_scores=top_scores, meets_threshold=meets_threshold
        )

    def prune_documents(self, query: str, documents: Sequence[str]) -> List[PrunedDocument]:
        return [self.prune(query, doc) for doc in documents]

    def build_context(self, query: str, documents: Sequence[str]) -> "HybridContext":
        pruned = self.prune_documents(query, documents)
        combined_text = "\n\n".join(
            f"<doc> {p.text} </doc>" for p in pruned if p.text
        )
        overall_meets_threshold = any(p.meets_threshold for p in pruned)
        return HybridContext(
            references_text=combined_text,
            pruned_documents=pruned,
            meets_threshold=overall_meets_threshold,
        )


@dataclass
class HybridContext:
    references_text: str
    pruned_documents: List[PrunedDocument]
    meets_threshold: bool
