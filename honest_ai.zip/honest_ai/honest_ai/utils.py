"""Small shared utilities."""
import json
import re
from typing import Any, Dict, Optional


def extract_first_json(text: str) -> Optional[Dict[str, Any]]:
    """Extract and parse the first top-level JSON object found in `text`.

    The paper notes: "Since sometimes the model generate additional text
    besides JSON output, additional code is written to extract the first
    JSON in the output to solve the problem." This reproduces that step by
    scanning for the first balanced {...} span and attempting to parse it.
    Returns None if no valid JSON object could be found.
    """
    start = text.find("{")
    while start != -1:
        depth = 0
        for i in range(start, len(text)):
            ch = text[i]
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidate = text[start : i + 1]
                    try:
                        return json.loads(candidate)
                    except json.JSONDecodeError:
                        break  # try the next '{'
        start = text.find("{", start + 1)
    return None


def normalize_answer(text: str) -> str:
    """Lowercase, strip punctuation/articles/extra whitespace for comparison."""
    if text is None:
        return ""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s]", " ", text)
    text = re.sub(r"\b(a|an|the)\b", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


IDK_PATTERNS = [
    "i don't know",
    "i dont know",
    "i do not know",
    "not sure",
    "unsure",
    "cannot determine",
    "no information",
    "insufficient information",
]

FALSE_PREMISE_PATTERNS = [
    "invalid question",
    "false premise",
    "no such",
    "does not exist",
    "doesn't exist",
    "did not happen",
    "didn't happen",
    "incorrect premise",
    "based on a false",
]


def looks_like_idk(text: str) -> bool:
    t = normalize_answer(text)
    return any(p in t or normalize_answer(p) in t for p in IDK_PATTERNS)


def looks_like_false_premise_flag(text: str) -> bool:
    t = normalize_answer(text)
    return any(normalize_answer(p) in t for p in FALSE_PREMISE_PATTERNS)
