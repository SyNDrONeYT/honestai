"""
Configuration constants taken directly from:

Chen, Wang, Wu, Tang, Liu (2024). "Honest AI: Fine-Tuning 'Small' Language
Models to Say 'I Don't Know', and Reducing Hallucination in RAG."
KDD Cup Workshop for RAG @ SIGKDD 2024. https://arxiv.org/abs/2410.09699

Section 3.4 (Fine-tuning) gives the exact QLoRA hyperparameters used by the
authors. Section 3.5 (Hybrid Approach) gives the pruner parameters (k, m, n)
and the domain used for RAG-first routing.
"""
from dataclasses import dataclass, field
from typing import List


@dataclass
class QLoRAConfig:
    """QLoRA hyperparameters, verbatim from Section 3.4 of the paper."""

    base_model: str = "meta-llama/Llama-2-7b-chat-hf"
    # The paper also tried Meta-Llama-3-8B-Instruct and found it performed
    # consistently worse for this task -- kept here for reproducibility.
    alt_model: str = "meta-llama/Meta-Llama-3-8B-Instruct"

    load_in_4bit: bool = True
    bnb_4bit_quant_type: str = "nf4"
    bnb_4bit_compute_dtype: str = "bfloat16"
    bnb_4bit_use_double_quant: bool = True

    lora_alpha: int = 16
    lora_r: int = 64
    lora_dropout: float = 0.1
    lora_target_modules: List[str] = field(
        default_factory=lambda: [
            "q_proj",
            "k_proj",
            "v_proj",
            "o_proj",
            "gate_proj",
            "up_proj",
            "down_proj",
        ]
    )

    per_device_train_batch_size: int = 8
    learning_rate: float = 2e-4
    weight_decay: float = 0.001
    num_train_epochs: int = 5
    max_seq_length: int = 2048

    output_dir: str = "./honest_ai_qlora_out"
    seed: int = 42


@dataclass
class DataConfig:
    """Dataset construction rules, verbatim from Section 3.4."""

    # Number of instances held out for offline evaluation (never trained on).
    num_holdout: int = 250

    # question_types that are NEVER relabeled to "i don't know", because the
    # paper found these categories benefit from being answered directly.
    keep_original_answer_question_types: List[str] = field(
        default_factory=lambda: ["comparison", "false_premise"]
    )

    # boolean-style answers that are also always kept as-is.
    keep_original_answer_values: List[str] = field(
        default_factory=lambda: ["yes", "no", "true", "false"]
    )

    idk_answer_text: str = "i don't know"


@dataclass
class RAGConfig:
    """Naive-RAG + Sentence-BERT pruner parameters, Section 3.5."""

    sentence_bert_model: str = "all-MiniLM-L6-v2"

    # k: number of top sentences (by cosine similarity to the query) to pull
    # from each retrieved document.
    top_k_sentences: int = 3

    # m: number of sentences following each top sentence, in the original
    # paragraph order, appended to enrich context.
    context_window_m: int = 2

    # n: cosine-similarity threshold. The retrieved context/answer is only
    # trusted if the top-k sentences meet this threshold. The paper reports
    # results for n = 0.75 and n = 0.8 (Table 3); 0.75 gave the best score.
    similarity_threshold_n: float = 0.75

    rag_model: str = "meta-llama/Meta-Llama-3-8B-Instruct"


@dataclass
class HybridConfig:
    """Hybrid-approach routing rule, Section 3.5."""

    # Domain the paper found had low hallucination rate for RAG and therefore
    # is trusted "RAG-first" before falling back to the fine-tuned model.
    rag_first_domains: List[str] = field(default_factory=lambda: ["movie"])

    valid_domains: List[str] = field(
        default_factory=lambda: [
            "finance",
            "sports",
            "music",
            "movie",
            "encyclopedia",
            "other",
        ]
    )

    invalid_question_text: str = "invalid question"
    idk_text: str = "i don't know"
