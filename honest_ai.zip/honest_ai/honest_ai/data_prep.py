"""
Dataset construction, reproducing Section 3.4 / Figure 3 of the paper.

Rule (quoted from the paper):
    "If the question_type is comparison or false_premise, or the answer is
    'yes', 'no', 'true' or 'false', we do not modify the answers to the
    questions; otherwise, we replace the original answer with 'i don't
    know'."

Then 250 instances are reserved (held out) for offline evaluation before
this relabeling-and-training data is used to fine-tune the model.
"""
import json
import random
from dataclasses import asdict
from typing import Dict, Iterable, List, Tuple

from .config import DataConfig


def relabel_example(example: Dict, cfg: DataConfig = DataConfig()) -> Dict:
    """Apply the paper's honesty-relabeling rule to a single CRAG-style example.

    `example` is expected to have at least the keys: "query", "answer",
    "question_type". Any other keys (domain, static_or_dynamic, search
    results, etc.) are passed through unchanged. A new key
    "original_answer" is added so the un-relabeled ground truth is never
    lost, and "answer" is overwritten in place if the rule says to relabel.
    """
    out = dict(example)
    question_type = str(example.get("question_type", "")).strip().lower()
    answer = str(example.get("answer", "")).strip().lower()

    out["original_answer"] = example.get("answer")

    keep_original = (
        question_type in cfg.keep_original_answer_question_types
        or answer in cfg.keep_original_answer_values
    )

    if not keep_original:
        out["answer"] = cfg.idk_answer_text
        out["was_relabeled"] = True
    else:
        out["was_relabeled"] = False

    return out


def build_finetune_dataset(
    raw_examples: List[Dict],
    cfg: DataConfig = DataConfig(),
    shuffle_seed: int = 42,
) -> Tuple[List[Dict], List[Dict]]:
    """Relabel + split raw CRAG-style examples into (train_data, holdout_data).

    Mirrors Fig. 3: examples are shuffled deterministically, `cfg.num_holdout`
    are reserved untouched (holdout keeps the *original* answer, since it is
    used for offline evaluation of real accuracy/hallucination, not for
    teaching the "i don't know" behavior), and the remainder is relabeled
    per `relabel_example` and used for QLoRA fine-tuning.
    """
    examples = list(raw_examples)
    rng = random.Random(shuffle_seed)
    rng.shuffle(examples)

    holdout = examples[: cfg.num_holdout]
    remainder = examples[cfg.num_holdout :]

    train_data = [relabel_example(ex, cfg) for ex in remainder]
    # Holdout set is left with its original, ground-truth answer intact.
    holdout_data = [dict(ex, original_answer=ex.get("answer")) for ex in holdout]

    return train_data, holdout_data


def to_sft_jsonl(
    examples: Iterable[Dict],
    out_path: str,
    prompt_template: str = "### Question\n{query}\n\n### Answer\n",
) -> None:
    """Write examples out in a simple instruction/response JSONL format
    suitable for most SFT trainers (e.g. TRL's SFTTrainer, axolotl, etc.).
    Each line: {"prompt": ..., "response": ...}
    """
    with open(out_path, "w", encoding="utf-8") as f:
        for ex in examples:
            row = {
                "prompt": prompt_template.format(query=ex["query"]),
                "response": str(ex["answer"]),
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def load_jsonl(path: str) -> List[Dict]:
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                data.append(json.loads(line))
    return data


def save_jsonl(examples: Iterable[Dict], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for ex in examples:
            f.write(json.dumps(ex, ensure_ascii=False) + "\n")
