"""
Scoring, reproducing Section 3.2 of the paper (itself following the CRAG
benchmark's evaluation, Yang et al. 2024):

    "If the response is perfect, it receives 1 point. If the response is
    acceptable, it receives 0.5 points. If the response is missing, i.e.
    'I don't know', it receives 0 points. If the response is incorrect, it
    receives -1 point."
    "The overall score is a macro-average across all domains."

Judging "perfect" vs "acceptable" vs "incorrect" for free-form answers is
inherently a semantic-equivalence problem. The reference CRAG benchmark
uses GPT-4 as an automatic judge for this; this module gives you:

  1. A fast, deterministic rule-based scorer (exact match / IDK / false
     premise detection) that reproduces the mechanical parts of the rubric
     exactly, and
  2. An optional `llm_judge` hook (any callable
     (question, ground_truth, prediction) -> "perfect"|"acceptable"|"incorrect")
     you can back with Claude, GPT-4, or a local model, to fill in the
     semantic-equivalence judgment the paper delegates to CRAG's judge.
"""
from collections import defaultdict
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

from .utils import looks_like_false_premise_flag, looks_like_idk, normalize_answer

Judgment = str  # "perfect" | "acceptable" | "missing" | "incorrect"

SCORE_MAP = {
    "perfect": 1.0,
    "acceptable": 0.5,
    "missing": 0.0,
    "incorrect": -1.0,
}

LLMJudge = Callable[[str, str, str], str]  # (question, ground_truth, prediction) -> "perfect"|"acceptable"|"incorrect"


@dataclass
class ScoredExample:
    query: str
    ground_truth: str
    prediction: str
    domain: Optional[str]
    judgment: Judgment
    score: float


def score_single(
    query: str,
    ground_truth: str,
    prediction: str,
    domain: Optional[str] = None,
    llm_judge: Optional[LLMJudge] = None,
) -> ScoredExample:
    gt_norm = normalize_answer(ground_truth)
    pred_is_idk = looks_like_idk(prediction)

    if gt_norm == normalize_answer("invalid question"):
        # Ground truth says the question has a false premise.
        if looks_like_false_premise_flag(prediction) or normalize_answer(prediction) == gt_norm:
            judgment = "perfect"
        elif pred_is_idk:
            judgment = "missing"
        else:
            judgment = "incorrect"
    else:
        if pred_is_idk:
            judgment = "missing"
        elif normalize_answer(prediction) == gt_norm:
            judgment = "perfect"
        elif llm_judge is not None:
            verdict = llm_judge(query, ground_truth, prediction)
            judgment = verdict if verdict in ("perfect", "acceptable", "incorrect") else "incorrect"
        else:
            # Fallback heuristic when no LLM judge is supplied: partial
            # token overlap counts as "acceptable", otherwise "incorrect".
            gt_tokens = set(gt_norm.split())
            pred_tokens = set(normalize_answer(prediction).split())
            overlap = len(gt_tokens & pred_tokens) / max(1, len(gt_tokens))
            judgment = "acceptable" if overlap >= 0.5 else "incorrect"

    return ScoredExample(
        query=query,
        ground_truth=ground_truth,
        prediction=prediction,
        domain=domain,
        judgment=judgment,
        score=SCORE_MAP[judgment],
    )


@dataclass
class EvaluationReport:
    per_example: List[ScoredExample]
    per_domain_score: Dict[str, float]
    exact_accuracy: float
    accuracy: float          # perfect + acceptable, weighted as in CRAG (perfect=1, acceptable counted as correct)
    hallucination_rate: float
    missing_rate: float
    macro_average_score: float


def evaluate(
    examples: List[dict],
    llm_judge: Optional[LLMJudge] = None,
) -> EvaluationReport:
    """Score a batch and reproduce the Table 2/3-style summary metrics.

    Each example dict needs: "query", "ground_truth", "prediction", and
    optionally "domain" (used for the macro-average across domains).
    """
    scored = [
        score_single(
            ex["query"], ex["ground_truth"], ex["prediction"], ex.get("domain"), llm_judge
        )
        for ex in examples
    ]

    n = len(scored)
    if n == 0:
        return EvaluationReport([], {}, 0.0, 0.0, 0.0, 0.0, 0.0)

    n_perfect = sum(s.judgment == "perfect" for s in scored)
    n_acceptable = sum(s.judgment == "acceptable" for s in scored)
    n_missing = sum(s.judgment == "missing" for s in scored)
    n_incorrect = sum(s.judgment == "incorrect" for s in scored)

    exact_accuracy = n_perfect / n
    accuracy = (n_perfect + n_acceptable) / n
    hallucination_rate = n_incorrect / n
    missing_rate = n_missing / n

    by_domain = defaultdict(list)
    for s in scored:
        by_domain[s.domain or "unknown"].append(s.score)
    per_domain_score = {d: sum(v) / len(v) for d, v in by_domain.items()}
    macro_average_score = sum(per_domain_score.values()) / len(per_domain_score)

    return EvaluationReport(
        per_example=scored,
        per_domain_score=per_domain_score,
        exact_accuracy=exact_accuracy,
        accuracy=accuracy,
        hallucination_rate=hallucination_rate,
        missing_rate=missing_rate,
        macro_average_score=macro_average_score,
    )


def print_report(report: EvaluationReport) -> None:
    print(f"{'Exact Accuracy':<18}{report.exact_accuracy:.3f}")
    print(f"{'Accuracy':<18}{report.accuracy:.3f}")
    print(f"{'Hallucination':<18}{report.hallucination_rate:.3f}")
    print(f"{'Missing':<18}{report.missing_rate:.3f}")
    print(f"{'Macro Avg Score':<18}{report.macro_average_score:.3f}")
    print("\nPer-domain score:")
    for domain, score in sorted(report.per_domain_score.items()):
        print(f"  {domain:<15}{score:.3f}")
