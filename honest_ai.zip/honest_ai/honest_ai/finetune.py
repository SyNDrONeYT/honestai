"""
QLoRA fine-tuning, reproducing Section 3.4 of the paper.

    "we decided to use the QLoRA technique to fine-tune the Llama-2-7b-chat
    in 4-bit precision ... We use Alpha=16, r=64, and Dropout=0.1 for QLoRA.
    Additionally, we use a batch size of 8, a learning rate of 0.0002, a
    weight decay of 0.001, and fine-tune the model for 5 epochs."

Requires: torch, transformers, peft, bitsandbytes, trl, datasets.
This module is import-light: heavy deps are only imported inside functions,
so the rest of the honest_ai package can be used/tested without a GPU.
"""
from dataclasses import asdict
from typing import List, Optional

from .config import QLoRAConfig
from .prompts import build_finetuned_prompt


def format_example(example: dict) -> dict:
    """Turn a {"prompt": ..., "response": ...} row (see data_prep.to_sft_jsonl)
    into a single training `text` field with the answer appended, which is
    what TRL's SFTTrainer / a plain causal-LM Trainer expects.
    """
    prompt = example.get("prompt") or build_finetuned_prompt(example["query"])
    response = example["response"] if "response" in example else example["answer"]
    text = f"{prompt}{response}"
    return {"text": text}


def build_model_and_tokenizer(cfg: QLoRAConfig):
    """Load the base model in 4-bit (QLoRA) precision and attach LoRA adapters."""
    import torch
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    compute_dtype = getattr(torch, cfg.bnb_4bit_compute_dtype)

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=cfg.load_in_4bit,
        bnb_4bit_quant_type=cfg.bnb_4bit_quant_type,
        bnb_4bit_compute_dtype=compute_dtype,
        bnb_4bit_use_double_quant=cfg.bnb_4bit_use_double_quant,
    )

    tokenizer = AutoTokenizer.from_pretrained(cfg.base_model)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        cfg.base_model,
        quantization_config=bnb_config,
        device_map="auto",
    )
    model = prepare_model_for_kbit_training(model)

    lora_config = LoraConfig(
        r=cfg.lora_r,
        lora_alpha=cfg.lora_alpha,
        lora_dropout=cfg.lora_dropout,
        target_modules=cfg.lora_target_modules,
        bias="none",
        task_type="CAUSAL_LM",
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    return model, tokenizer


def run_finetune(
    train_jsonl_path: str,
    cfg: QLoRAConfig = QLoRAConfig(),
    eval_jsonl_path: Optional[str] = None,
):
    """End-to-end QLoRA SFT run using TRL's SFTTrainer.

    train_jsonl_path / eval_jsonl_path should point at files produced by
    honest_ai.data_prep.to_sft_jsonl (rows of {"prompt", "response"}).
    """
    from datasets import load_dataset
    from transformers import TrainingArguments, set_seed
    from trl import SFTTrainer

    set_seed(cfg.seed)

    model, tokenizer = build_model_and_tokenizer(cfg)

    data_files = {"train": train_jsonl_path}
    if eval_jsonl_path:
        data_files["eval"] = eval_jsonl_path
    raw_datasets = load_dataset("json", data_files=data_files)

    train_dataset = raw_datasets["train"].map(
        format_example, remove_columns=raw_datasets["train"].column_names
    )
    eval_dataset = None
    if eval_jsonl_path:
        eval_dataset = raw_datasets["eval"].map(
            format_example, remove_columns=raw_datasets["eval"].column_names
        )

    training_args = TrainingArguments(
        output_dir=cfg.output_dir,
        per_device_train_batch_size=cfg.per_device_train_batch_size,
        learning_rate=cfg.learning_rate,
        weight_decay=cfg.weight_decay,
        num_train_epochs=cfg.num_train_epochs,
        logging_steps=10,
        save_strategy="epoch",
        evaluation_strategy="epoch" if eval_dataset is not None else "no",
        bf16=True,
        report_to=[],
        seed=cfg.seed,
    )

    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        dataset_text_field="text",
        max_seq_length=cfg.max_seq_length,
    )

    trainer.train()
    trainer.save_model(cfg.output_dir)
    tokenizer.save_pretrained(cfg.output_dir)
    return trainer
