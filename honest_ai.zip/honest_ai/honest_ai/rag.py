"""
Naive RAG, reproducing Section 3.3 of the paper.

    "Generally, naive RAG selects the highest cosine similarity results
    from a vector database and supplies the context as inputs for LLMs."

This module retrieves whole documents by cosine similarity; the finer-
grained sentence-level pruning (Section 3.5, k/m/n) lives in pruner.py and
is applied to whatever documents this retriever returns.
"""
from dataclasses import dataclass
from typing import List, Sequence

import numpy as np

from .pruner import cosine_similarity


@dataclass
class RetrievedDocument:
    text: str
    score: float


class NaiveRAGRetriever:
    """Cosine-similarity retrieval over a fixed in-memory document store,
    using Sentence-BERT (or any encoder exposing `.encode`) embeddings.

    For the CRAG competition setting, `documents` would be the mock
    search-API / knowledge-graph results returned for a given query; in
    general use, populate this from your own vector database.
    """

    def __init__(self, documents: Sequence[str], embedder=None):
        self.documents = list(documents)
        if embedder is not None:
            self._model = embedder
        else:
            from sentence_transformers import SentenceTransformer

            self._model = SentenceTransformer("all-MiniLM-L6-v2")
        self._doc_embeddings = (
            np.asarray(self._model.encode(self.documents, convert_to_numpy=True))
            if self.documents
            else np.zeros((0, 384))
        )

    def retrieve(self, query: str, top_k: int = 5) -> List[RetrievedDocument]:
        if not self.documents:
            return []
        query_emb = np.asarray(self._model.encode([query], convert_to_numpy=True))[0]
        scores = cosine_similarity(query_emb, self._doc_embeddings)
        top_k = min(top_k, len(self.documents))
        top_idx = np.argsort(-scores)[:top_k]
        return [RetrievedDocument(text=self.documents[i], score=float(scores[i])) for i in top_idx]
