"""
Prompt templates.

The JSON-output prompt below is quoted (with only whitespace formatting
adjusted) from Appendix A.1 of the paper. It is used by the RAG / hybrid
model to jointly (a) classify the question's domain and (b) produce the
answer, in one JSON object.
"""

DOMAIN_AND_ANSWER_PROMPT_TEMPLATE = """You are an agent that only outputs JSON. You are given a Query and References. Do the following:

1. Determine the domain the query is about. The domain should be one of the following: "finance", "sports", "music", "movie", "encyclopedia". If none of the domains apply, use "other". Use "domain" as the key in the result json.
2. Answer the question in as few words as possible. Please follow these guidelines when formulating your answer. If the question contains a false premise or assumption, answer "invalid question". If you are uncertain or don't know the answer, respond with "I don't know". Use "answer" as the key in the result json.

### Question
{query}

### References
{references}

### Answer
"""


def build_domain_and_answer_prompt(query: str, references: str) -> str:
    """Fill in the Appendix A.1 prompt with a query and a references blob.

    `references` should already be the pruned/concatenated context text
    (see honest_ai.pruner.SentenceBertPruner) -- this function does not
    truncate or format the references further.
    """
    return DOMAIN_AND_ANSWER_PROMPT_TEMPLATE.format(query=query, references=references)


# Simple instruction-only prompt for the fine-tuned ("Honest AI") model,
# which was trained on relabeled data and does not need the JSON/domain
# scaffolding -- it just answers or says "i don't know" directly.
FINE_TUNED_MODEL_PROMPT_TEMPLATE = """Answer the following question as concisely as possible. If you are not confident in the answer, or the question contains a false premise, respond honestly.

### Question
{query}

### Answer
"""


def build_finetuned_prompt(query: str) -> str:
    return FINE_TUNED_MODEL_PROMPT_TEMPLATE.format(query=query)
