import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from honest_ai.config import HybridConfig, RAGConfig
from honest_ai.hybrid import HybridAnswerer
from honest_ai.pruner import SentenceBertPruner


class FakeEmbedder:
    """Deterministic bag-of-words embedder standing in for Sentence-BERT so
    the pruner/retriever logic can be tested without downloading a model.
    """

    def encode(self, texts, convert_to_numpy=True):
        vocab = {}

        def vec(text):
            words = text.lower().split()
            v = np.zeros(50)
            for w in words:
                idx = vocab.setdefault(w, len(vocab) % 50)
                v[idx] += 1.0
            return v

        return np.stack([vec(t) for t in texts])


class FakeRAGGenerator:
    """Always returns a canned domain+answer JSON string."""

    def __init__(self, domain: str, answer: str):
        self.domain = domain
        self.answer = answer

    def generate(self, prompt: str, **kwargs) -> str:
        return f'Sure, here it is:\n{{"domain": "{self.domain}", "answer": "{self.answer}"}}'


class FakeFineTunedModel:
    def answer(self, query: str, **kwargs) -> str:
        return "i don't know"


def test_pruner_selects_relevant_sentences_with_fake_embedder():
    cfg = RAGConfig(top_k_sentences=1, context_window_m=1, similarity_threshold_n=0.0)
    pruner = SentenceBertPruner(cfg, model=FakeEmbedder())
    doc = "The sky is blue. Inception was directed by Christopher Nolan. It won an Oscar."
    pruned = pruner.prune("who directed Inception", doc)
    assert "Inception" in pruned.text
    assert pruned.meets_threshold  # threshold is 0.0, always met


def test_hybrid_routes_to_rag_for_movie_domain_when_valid():
    hybrid_cfg = HybridConfig()
    rag_cfg = RAGConfig(similarity_threshold_n=0.0)
    pruner = SentenceBertPruner(rag_cfg, model=FakeEmbedder())
    rag_gen = FakeRAGGenerator(domain="movie", answer="Inception")
    ft_model = FakeFineTunedModel()

    answerer = HybridAnswerer(rag_gen, ft_model, pruner=pruner, hybrid_cfg=hybrid_cfg, rag_cfg=rag_cfg)
    result = answerer.answer("what 2010 film was directed by christopher nolan?", ["Inception is a 2010 film directed by Christopher Nolan."])

    assert result.used_source == "rag"
    assert result.final_answer == "Inception"
    assert result.domain == "movie"


def test_hybrid_falls_back_to_fine_tuned_for_non_movie_domain():
    hybrid_cfg = HybridConfig()
    rag_cfg = RAGConfig(similarity_threshold_n=0.0)
    pruner = SentenceBertPruner(rag_cfg, model=FakeEmbedder())
    rag_gen = FakeRAGGenerator(domain="finance", answer="$42")
    ft_model = FakeFineTunedModel()

    answerer = HybridAnswerer(rag_gen, ft_model, pruner=pruner, hybrid_cfg=hybrid_cfg, rag_cfg=rag_cfg)
    result = answerer.answer("what was Apple's stock price yesterday?", ["Some finance doc."])

    assert result.used_source == "fine_tuned"
    assert result.final_answer == "i don't know"
    assert result.invalid_reason == "not_rag_first_domain"


def test_hybrid_falls_back_when_rag_answer_is_invalid_question():
    hybrid_cfg = HybridConfig()
    rag_cfg = RAGConfig(similarity_threshold_n=0.0)
    pruner = SentenceBertPruner(rag_cfg, model=FakeEmbedder())
    rag_gen = FakeRAGGenerator(domain="movie", answer="invalid question")
    ft_model = FakeFineTunedModel()

    answerer = HybridAnswerer(rag_gen, ft_model, pruner=pruner, hybrid_cfg=hybrid_cfg, rag_cfg=rag_cfg)
    result = answerer.answer("when did Hamburg become the biggest city of Germany?", ["Berlin is the biggest city."])

    assert result.used_source == "fine_tuned"
    assert result.invalid_reason == "invalid_question"


def test_hybrid_falls_back_on_json_processing_error():
    class BrokenGenerator:
        def generate(self, prompt, **kwargs):
            return "I refuse to output JSON today."

    hybrid_cfg = HybridConfig()
    rag_cfg = RAGConfig(similarity_threshold_n=0.0)
    pruner = SentenceBertPruner(rag_cfg, model=FakeEmbedder())
    ft_model = FakeFineTunedModel()

    answerer = HybridAnswerer(BrokenGenerator(), ft_model, pruner=pruner, hybrid_cfg=hybrid_cfg, rag_cfg=rag_cfg)
    result = answerer.answer("some question", ["some doc"])

    assert result.used_source == "fine_tuned"
    assert result.invalid_reason == "json_processing_error"
