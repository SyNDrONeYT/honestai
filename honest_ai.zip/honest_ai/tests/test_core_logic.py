import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from honest_ai.config import DataConfig, HybridConfig
from honest_ai.data_prep import build_finetune_dataset, relabel_example
from honest_ai.evaluate import evaluate, score_single
from honest_ai.pruner import cosine_similarity, split_into_sentences
from honest_ai.utils import extract_first_json, looks_like_idk


def test_relabel_keeps_comparison_and_false_premise():
    cfg = DataConfig()
    ex1 = {"query": "q", "answer": "Paris", "question_type": "comparison"}
    ex2 = {"query": "q", "answer": "invalid question", "question_type": "false_premise"}
    out1 = relabel_example(ex1, cfg)
    out2 = relabel_example(ex2, cfg)
    assert out1["answer"] == "Paris"
    assert out1["was_relabeled"] is False
    assert out2["answer"] == "invalid question"
    assert out2["was_relabeled"] is False


def test_relabel_keeps_boolean_answers():
    cfg = DataConfig()
    for ans in ["yes", "No", "TRUE", "false"]:
        ex = {"query": "q", "answer": ans, "question_type": "simple"}
        out = relabel_example(ex, cfg)
        assert out["answer"] == ans
        assert out["was_relabeled"] is False


def test_relabel_replaces_other_answers_with_idk():
    cfg = DataConfig()
    ex = {"query": "who directed inception", "answer": "Christopher Nolan", "question_type": "simple"}
    out = relabel_example(ex, cfg)
    assert out["answer"] == "i don't know"
    assert out["was_relabeled"] is True
    assert out["original_answer"] == "Christopher Nolan"


def test_holdout_split_size_and_untouched_answers():
    cfg = DataConfig(num_holdout=10)
    raw = [
        {"query": f"q{i}", "answer": f"a{i}", "question_type": "simple"} for i in range(100)
    ]
    train, holdout = build_finetune_dataset(raw, cfg, shuffle_seed=1)
    assert len(holdout) == 10
    assert len(train) == 90
    # Holdout answers must be untouched (never relabeled to IDK).
    for ex in holdout:
        assert ex["answer"] == ex["original_answer"]
        assert not ex["answer"] == "i don't know" or ex["original_answer"] == "i don't know"


def test_extract_first_json_ignores_surrounding_text():
    text = 'Sure! Here you go:\n{"domain": "movie", "answer": "Inception"}\nHope that helps.'
    parsed = extract_first_json(text)
    assert parsed == {"domain": "movie", "answer": "Inception"}


def test_extract_first_json_handles_nested_braces():
    text = 'blah {"a": {"b": 1}, "c": "x"} trailing'
    parsed = extract_first_json(text)
    assert parsed == {"a": {"b": 1}, "c": "x"}


def test_extract_first_json_returns_none_when_absent():
    assert extract_first_json("no json here at all") is None


def test_looks_like_idk():
    assert looks_like_idk("I don't know")
    assert looks_like_idk("i dont know, sorry")
    assert not looks_like_idk("Christopher Nolan")


def test_scoring_perfect_missing_incorrect():
    perfect = score_single("who directed inception", "Christopher Nolan", "Christopher Nolan")
    missing = score_single("who directed inception", "Christopher Nolan", "I don't know")
    incorrect = score_single("who directed inception", "Christopher Nolan", "Steven Spielberg")
    assert perfect.judgment == "perfect" and perfect.score == 1.0
    assert missing.judgment == "missing" and missing.score == 0.0
    assert incorrect.judgment == "incorrect" and incorrect.score == -1.0


def test_scoring_false_premise_handling():
    correct_flag = score_single(
        "what 90s rap album did Taylor Swift release", "invalid question", "This is an invalid question -- Taylor Swift never released a rap album."
    )
    missed_flag = score_single(
        "what 90s rap album did Taylor Swift release", "invalid question", "I don't know"
    )
    wrong = score_single(
        "what 90s rap album did Taylor Swift release", "invalid question", "1989"
    )
    assert correct_flag.judgment == "perfect"
    assert missed_flag.judgment == "missing"
    assert wrong.judgment == "incorrect"


def test_macro_average_across_domains():
    examples = [
        {"query": "q1", "ground_truth": "A", "prediction": "A", "domain": "movie"},
        {"query": "q2", "ground_truth": "B", "prediction": "I don't know", "domain": "movie"},
        {"query": "q3", "ground_truth": "C", "prediction": "wrong", "domain": "finance"},
    ]
    report = evaluate(examples)
    # movie domain: (1.0 + 0.0) / 2 = 0.5 ; finance domain: -1.0
    assert abs(report.per_domain_score["movie"] - 0.5) < 1e-9
    assert abs(report.per_domain_score["finance"] - (-1.0)) < 1e-9
    assert abs(report.macro_average_score - ((0.5 + -1.0) / 2)) < 1e-9


def test_cosine_similarity_matches_manual_computation():
    a = np.array([1.0, 0.0])
    b = np.array([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])
    sims = cosine_similarity(a, b)
    assert np.isclose(sims[0], 1.0)
    assert np.isclose(sims[1], 0.0)
    assert np.isclose(sims[2], 1 / np.sqrt(2))


def test_split_into_sentences_basic():
    text = "Michael Bay was born on Feb 17, 1965. He is a film director. He is known for Transformers."
    sents = split_into_sentences(text)
    assert len(sents) == 3
    assert sents[0].startswith("Michael Bay")
