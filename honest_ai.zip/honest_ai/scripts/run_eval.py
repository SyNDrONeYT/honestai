#!/usr/bin/env python
"""
Offline evaluation, reproducing Section 3.2's scoring on a set of
{query, ground_truth, prediction, domain} rows -- e.g. run your fine-tuned
model or hybrid pipeline over honest_ai's holdout.jsonl first, dump
predictions to a JSONL, then score them here.

Input predictions JSONL rows: {"query": ..., "ground_truth": ..., "prediction": ..., "domain": ...}

Usage:
    python scripts/run_eval.py --predictions preds.jsonl
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from honest_ai.data_prep import load_jsonl
from honest_ai.evaluate import evaluate, print_report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", required=True)
    args = parser.parse_args()

    examples = load_jsonl(args.predictions)
    report = evaluate(examples)
    print_report(report)


if __name__ == "__main__":
    main()
