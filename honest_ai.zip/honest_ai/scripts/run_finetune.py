#!/usr/bin/env python
"""
Run QLoRA fine-tuning with the paper's exact hyperparameters (Section 3.4).

Usage:
    python scripts/run_finetune.py \
        --train_sft data/train_sft.jsonl \
        --base_model meta-llama/Llama-2-7b-chat-hf \
        --output_dir ./honest_ai_qlora_out
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from honest_ai.config import QLoRAConfig
from honest_ai.finetune import run_finetune


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_sft", required=True, help="prompt/response JSONL from prepare_data.py --sft_out")
    parser.add_argument("--eval_sft", default=None)
    parser.add_argument("--base_model", default=QLoRAConfig.base_model)
    parser.add_argument("--output_dir", default=QLoRAConfig.output_dir)
    parser.add_argument("--epochs", type=int, default=QLoRAConfig.num_train_epochs)
    parser.add_argument("--batch_size", type=int, default=QLoRAConfig.per_device_train_batch_size)
    parser.add_argument("--lr", type=float, default=QLoRAConfig.learning_rate)
    args = parser.parse_args()

    cfg = QLoRAConfig(
        base_model=args.base_model,
        output_dir=args.output_dir,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        learning_rate=args.lr,
    )

    print("QLoRA config:", cfg)
    run_finetune(args.train_sft, cfg=cfg, eval_jsonl_path=args.eval_sft)


if __name__ == "__main__":
    main()
