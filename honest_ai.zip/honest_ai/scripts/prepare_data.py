#!/usr/bin/env python
"""
Prepare CRAG-style JSONL data for QLoRA fine-tuning, applying the paper's
honesty-relabeling rule and 250-example holdout split (Section 3.4).

Input JSONL rows must contain at least: query, answer, question_type.
(Optionally: domain, static_or_dynamic, search_results, etc. -- passed through.)

Usage:
    python scripts/prepare_data.py \
        --input path/to/crag_train.jsonl \
        --train_out data/train_relabeled.jsonl \
        --holdout_out data/holdout.jsonl \
        --num_holdout 250
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from honest_ai.config import DataConfig
from honest_ai.data_prep import build_finetune_dataset, save_jsonl, to_sft_jsonl
from honest_ai.data_prep import load_jsonl as load_raw_jsonl


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Raw CRAG-style JSONL")
    parser.add_argument("--train_out", required=True, help="Relabeled train JSONL (raw fields)")
    parser.add_argument("--holdout_out", required=True, help="Holdout JSONL (raw fields, untouched answers)")
    parser.add_argument("--sft_out", default=None, help="Optional: also write prompt/response SFT JSONL for training")
    parser.add_argument("--num_holdout", type=int, default=250)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    cfg = DataConfig(num_holdout=args.num_holdout)
    raw = load_raw_jsonl(args.input)
    print(f"Loaded {len(raw)} raw examples from {args.input}")

    train_data, holdout_data = build_finetune_dataset(raw, cfg, shuffle_seed=args.seed)
    n_relabeled = sum(ex.get("was_relabeled", False) for ex in train_data)
    print(f"Train set: {len(train_data)} examples ({n_relabeled} relabeled to 'i don't know')")
    print(f"Holdout set: {len(holdout_data)} examples (answers untouched)")

    save_jsonl(train_data, args.train_out)
    save_jsonl(holdout_data, args.holdout_out)

    if args.sft_out:
        to_sft_jsonl(train_data, args.sft_out)
        print(f"Wrote SFT-format training file to {args.sft_out}")


if __name__ == "__main__":
    main()
